from odoo import fields, models, api


class StateChange(models.Model):
    _inherit = 'account.move'

    relation_id = fields.Many2one('guest.details')

    @api.constrains('payment_state')
    def _payment_stage(self):
        guest_ids = self.env['guest.details'].search([])
        for record in self:
            if record.payment_state == 'paid':
                for guest in guest_ids:
                    guest.payment_stage = True
